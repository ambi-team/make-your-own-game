public static class SettingsSingleton
{
    public static SettingsData Data;
}