﻿public static class StatsSingleton
{
	public static StatsData Data;
}