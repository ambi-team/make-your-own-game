﻿public interface IUsable
{
    public void Use(Player ply) { }
}