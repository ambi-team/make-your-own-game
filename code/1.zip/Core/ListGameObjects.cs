﻿public sealed class ListGameObjects : Component
{
	[Property] public List<GameObject> Objects { get; set; }
}