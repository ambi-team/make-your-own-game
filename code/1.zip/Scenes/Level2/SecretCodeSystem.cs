﻿using System;

public sealed class SecretCodeSystem : Component
{
	#region Props/Vars
	#endregion

	#region Logic
	#endregion

	#region Components
	#endregion
}