﻿public interface ISaveData
{
	public void Save();
	public void Load();
}